// import UsersService from "#root/adapters/UsersService";
// import { UserSessionType } from "#root/graphql/types";

// const UserSession = {
//   user: async (currentUser: UserSessionType) => {
//     // console.log("ttt", currentUser.user.accessToken);
//     return await UsersService.fetchUser({
//       accessToken: currentUser.user.accessToken,
//     });
//   },
// };

// export default UserSession;
