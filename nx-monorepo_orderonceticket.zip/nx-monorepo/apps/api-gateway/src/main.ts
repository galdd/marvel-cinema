// import "graphql-import-node";
import startServer from '#root/server/startServer';

startServer();
