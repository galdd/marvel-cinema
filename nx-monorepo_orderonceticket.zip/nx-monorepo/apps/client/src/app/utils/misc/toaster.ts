import { Position, Toaster } from "@blueprintjs/core";

const toaster = Toaster.create({
  position: Position.TOP,
});

export default toaster;
