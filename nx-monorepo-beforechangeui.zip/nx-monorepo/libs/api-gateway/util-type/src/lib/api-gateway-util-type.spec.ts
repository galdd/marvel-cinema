import { apiGatewayUtilType } from './api-gateway-util-type';

describe('apiGatewayUtilType', () => {
  it('should work', () => {
    expect(apiGatewayUtilType()).toEqual('api-gateway-util-type');
  });
});
