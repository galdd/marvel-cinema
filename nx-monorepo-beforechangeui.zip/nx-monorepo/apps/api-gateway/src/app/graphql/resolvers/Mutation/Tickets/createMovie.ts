import TicketsService from '#root/adapters/TicketsService';

interface Args {
  title: string;
  desc: string;
  img: string;
  imgTitle: string;
  imgSm: string;
  trailer: string;
  year: string;
  chronologicalOrder: number;
  length: string;
  imdbApiId: string;
}

const createShowResolver = async (
  obj: any,
  {
    title,
    desc,
    img,
    imgTitle,
    imgSm,
    trailer,
    year,
    chronologicalOrder,
    length,
    imdbApiId,
  }: Args,
) => {
  return await TicketsService.createMovie({
    title,
    desc,
    img,
    imgTitle,
    imgSm,
    trailer,
    year,
    chronologicalOrder,
    length,
    imdbApiId,
  });
};

export default createShowResolver;
