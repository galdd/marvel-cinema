// import OrdersService from "#root/adapters/OrdersService";

// interface Args {
//   userId: string;
//   ticketId: string;
//   status: string;
//   expiresAt: Date;
// }

// const signupResolver = async (
//   obj: any,
//   { userId, ticketId, status, expiresAt }: Args
// ) => {
//   return await OrdersService.createOrder({
//     userId,
//     ticketId,
//     status,
//     expiresAt,
//   });
// };

// export default signupResolver;
