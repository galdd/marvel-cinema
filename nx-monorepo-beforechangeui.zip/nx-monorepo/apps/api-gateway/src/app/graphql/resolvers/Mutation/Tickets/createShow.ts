import TicketsService from '#root/adapters/TicketsService';

interface Args {
  ticketAmount: number;
  dateAndTIme: Date;
  price: number;
  imdbApiId: string;
  movieId: string;
}

const createShowResolver = async (
  obj: any,
  { ticketAmount, dateAndTIme, price, imdbApiId, movieId }: Args,
) => {
  return await TicketsService.createShow({
    ticketAmount,
    dateAndTIme,
    price,
    imdbApiId,
    movieId,
  });
};

export default createShowResolver;
