import styles from './signup.module.scss';

/* eslint-disable-next-line */
export interface SignupProps {}

export function Signup(props: SignupProps) {
  return (
    <div className={styles['container']}>
      <h1>Welcome to Signup!</h1>
    </div>
  );
}

export default Signup;
