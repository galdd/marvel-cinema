export const PORT = 7000;
export const AUTH_PORT = 7001;
export const TICKETS_PORT = 7002;
export const ORDERS_PORT = 7003;

// export const USERS_SERVICE_URI = "http://users-service:7101";
export const USERS_SERVICE_URI = 'http://localhost:7001';
export const TICKETS_SERVICE_URI = 'http://localhost:7002';
export const ORDERS_SERVICE_URI = 'http://localhost:7003';
